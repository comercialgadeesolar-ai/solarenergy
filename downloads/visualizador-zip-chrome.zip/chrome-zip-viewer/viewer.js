import { openZip } from './zip-reader.js';
import { prepareSave, safeName, isCancelled } from './save-file.js';
const $ = selector => document.querySelector(selector);
let archive = null;
let selected = null;
let selectedBytes = null;
let selectionVersion = 0;
let loadVersion = 0;
let previewUrl = null;
let archiveFile = null;
let filesToCompress = [];
const size = bytes => new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 1 }).format(bytes / 1024) + ' KB';

function error(message) { $('#error').textContent = message;$('#error').hidden = false; }
function clearPreview() {
  if (previewUrl) URL.revokeObjectURL(previewUrl);
  previewUrl = null;
  $('#preview-content').replaceChildren();
  $('#preview-note').hidden = true;
}
function listFiles() {
  const filter = $('#search').value.toLocaleLowerCase('pt-BR');
  const list = $('#file-list');
  list.replaceChildren();
  const matches = archive.entries.filter(entry => entry.path.toLocaleLowerCase('pt-BR').includes(filter));
  for (const entry of matches) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'file-item';
    button.setAttribute('aria-pressed', String(selected === entry));
    const title = document.createElement('span');title.className = 'file-path';title.textContent = entry.path;
    const detail = document.createElement('small');detail.textContent = size(entry.size);
    button.append(title, detail);
    button.addEventListener('click', () => selectFile(entry));
    list.append(button);
  }
  if (!matches.length) { const p = document.createElement('p');p.className = 'empty';p.textContent = 'Nenhum arquivo encontrado.';list.append(p); }
}
async function selectFile(entry) {
  const version = ++selectionVersion;
  const current = archive;
  selected = entry;selectedBytes = null;
  $('#error').hidden = true;
  $('#download').disabled = true;
  $('#selected-name').textContent = entry.path;
  $('#selected-details').textContent = 'Verificando e abrindo arquivo...';
  clearPreview();listFiles();
  try {
    const bytes = await current.extract(entry);
    if (version !== selectionVersion || current !== archive) return;
    selectedBytes = bytes;
    $('#download').disabled = false;
    $('#selected-details').textContent = size(entry.size) + ' · Integridade CRC32 verificada';
    const extension = entry.path.split('.').pop().toLowerCase();
    const content = $('#preview-content');
    if (['html', 'htm'].includes(extension)) {
      const iframe = document.createElement('iframe');
      iframe.title = 'Prévia HTML: ' + entry.path;
      iframe.setAttribute('sandbox', '');
      iframe.setAttribute('referrerpolicy', 'no-referrer');
      const policy = '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; img-src data: blob:; font-src data:; base-uri \'none\'; form-action \'none\'">';
      iframe.srcdoc = policy + new TextDecoder().decode(bytes);
      content.append(iframe);
      $('#preview-note').textContent = 'Prévia HTML estática. Scripts e recursos externos não são executados. Para testar o 3D, baixe o HTML autocontido e abra-o no Chrome.';
      $('#preview-note').hidden = false;
    } else if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'avif', 'bmp', 'ico'].includes(extension)) {
      const mime = { jpg: 'image/jpeg', jpeg: 'image/jpeg', svg: 'image/svg+xml', ico: 'image/x-icon' }[extension] || 'image/' + extension;
      previewUrl = URL.createObjectURL(new Blob([bytes], { type: mime }));
      const image = document.createElement('img');image.src = previewUrl;image.alt = entry.path;content.append(image);
    } else if (['txt','md','css','js','mjs','json','php','xml','yml','yaml','csv','log','gitignore','sh'].includes(extension) || !entry.path.split('/').pop().includes('.')) {
      const pre = document.createElement('pre');pre.textContent = new TextDecoder().decode(bytes);content.append(pre);
    } else {
      const p = document.createElement('p');p.className = 'empty';p.textContent = 'Este formato não possui prévia. Use “Baixar arquivo” para abri-lo no aplicativo apropriado.';content.append(p);
    }
    $('#status').textContent = 'Arquivo aberto: ' + entry.path;
  } catch (exception) {
    if (version !== selectionVersion || current !== archive) return;
    error(exception.message);$('#selected-details').textContent = 'Não foi possível abrir este arquivo.';
  }
}
async function loadFile(file) {
  if (!file) return;
  const version = ++loadVersion;
  selectionVersion++;
  archive = null;archiveFile = null;selected = null;selectedBytes = null;
  $('#save-zip').disabled = true;
  $('#workspace').hidden = true;$('#error').hidden = true;$('#download').disabled = true;
  clearPreview();$('#status').textContent = 'Lendo ' + file.name + '...';
  try {
    const opened = await openZip(file);
    if (version !== loadVersion) return;
    archive = opened;
    archiveFile = file;
    $('#save-zip').disabled = false;
    $('#archive-name').textContent = archive.name;
    $('#archive-details').textContent = archive.entries.length + ' arquivos · ' + size(archive.total) + ' descompactados';
    $('#search').value = '';
    $('#selected-name').textContent = 'Selecione um arquivo';$('#selected-details').textContent = 'A prévia aparecerá aqui.';
    $('#workspace').hidden = false;listFiles();
    $('#status').textContent = 'ZIP aberto. Escolha um arquivo para visualizar.';
  } catch (exception) {
    if (version !== loadVersion) return;
    error(exception.message);$('#status').textContent = 'Não foi possível abrir o ZIP.';
  }
}
$('#zip-file').addEventListener('change', event => { loadFile(event.target.files[0]);event.target.value = ''; });
$('#search').addEventListener('input', listFiles);
$('#download').addEventListener('click', async () => {
  if (!selected || !selectedBytes) return;
  const bytes = selectedBytes;
  const filename = selected.path.split('/').pop();
  try {
    const save = await prepareSave(filename, 'application/octet-stream');
    await save(bytes);$('#status').textContent = 'Salvamento solicitado: ' + filename;
  } catch (exception) { if (isCancelled(exception)) $('#status').textContent = 'Salvamento cancelado.';else error(exception.message); }
});
$('#save-zip').addEventListener('click', async () => {
  if (!archiveFile) return;
  const file = archiveFile;
  try {
    const save = await prepareSave(file.name, 'application/zip');
    await save(await file.arrayBuffer());$('#status').textContent = 'Salvamento solicitado: ' + file.name;
  } catch (exception) { if (isCancelled(exception)) $('#status').textContent = 'Salvamento cancelado.';else error(exception.message); }
});

function selectForCompression(event) {
  filesToCompress = Array.from(event.target.files);
  const total = filesToCompress.reduce((sum, file) => sum + file.size, 0);
  $('#create-selection').textContent = filesToCompress.length + ' arquivos selecionados · ' + size(total);
  $('#create-zip').disabled = filesToCompress.length === 0;
  $('#create-status').textContent = '';
  event.target.value = '';
}
$('#create-files').addEventListener('change', selectForCompression);
$('#create-folder').addEventListener('change', selectForCompression);
$('#create-zip').addEventListener('click', async () => {
  if (!filesToCompress.length) return;
  const files = filesToCompress.slice();
  const inputs = ['#create-files', '#create-folder', '#create-zip', '#zip-name'];
  inputs.forEach(selector => { $(selector).disabled = true; });
  $('#error').hidden = true;$('#create-status').textContent = 'Compactando em ZIP…';
  let worker;
  try {
    if (files.length > 5000 || files.some(file => file.size > 32 * 1024 ** 2) || files.reduce((sum, file) => sum + file.size, 0) > 128 * 1024 ** 2) throw new Error('Seleção acima dos limites: 5.000 arquivos, 32 MB por arquivo e 128 MB no total.');
    let filename = safeName($('#zip-name').value, 'meus-arquivos.zip');
    if (!filename.toLowerCase().endsWith('.zip')) filename += '.zip';
    $('#zip-name').value = filename;
    const entries = await Promise.all(files.map(async file => ({ path: file.webkitRelativePath || file.name, bytes: await file.arrayBuffer() })));
    worker = new Worker(new URL('./zip-worker.js', import.meta.url), { type: 'module' });
    const bytes = await new Promise((resolve, reject) => {
      worker.onmessage = event => event.data.error ? reject(new Error(event.data.error)) : resolve(event.data.bytes);
      worker.onerror = () => reject(new Error('Não foi possível iniciar a compactação. Recarregue a extensão e tente novamente.'));
      worker.postMessage(entries, entries.map(entry => entry.bytes));
    });
    await loadFile(new File([bytes], filename, { type: 'application/zip' }));
    if (!archiveFile) throw new Error('O ZIP foi criado, mas não pôde ser validado.');
    const originalSize = files.reduce((sum, file) => sum + file.size, 0);
    const reduction = originalSize ? Math.round((1 - bytes.byteLength / originalSize) * 1000) / 10 : 0;
    $('#create-status').textContent = 'ZIP pronto: ' + size(bytes.byteLength) + (reduction > 0 ? ' · redução de ' + reduction.toLocaleString('pt-BR') + '%' : '') + '. Clique em “Salvar ZIP como…” para escolher a pasta.';
  } catch (exception) { error(exception.message);$('#create-status').textContent = 'Não foi possível criar o ZIP.'; }
  finally { worker?.terminate();inputs.forEach(selector => { $(selector).disabled = false; }); }
});
const dropZone = $('#drop-zone');
for (const type of ['dragenter', 'dragover']) dropZone.addEventListener(type, event => { event.preventDefault();dropZone.classList.add('dragging'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragging'));
dropZone.addEventListener('drop', event => { event.preventDefault();dropZone.classList.remove('dragging');loadFile(event.dataTransfer.files[0]); });
