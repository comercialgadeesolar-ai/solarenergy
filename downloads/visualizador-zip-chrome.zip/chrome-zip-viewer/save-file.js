export function safeName(name, fallback = 'arquivo') {
  return (name.replace(/[<>:"/\\|?*\u0000-\u001f]/g, '-').replace(/[. ]+$/g, '').trim() || fallback).slice(0, 180);
}

export async function prepareSave(name, mime) {
  const filename = safeName(name);
  if (globalThis.chrome?.runtime?.id && chrome.downloads?.download) {
    return async bytes => {
      const url = URL.createObjectURL(new Blob([bytes], { type: mime }));
      try {
        const downloadId = await chrome.downloads.download({ url, filename, saveAs: true, conflictAction: 'uniquify' });
        const cleanup = delta => {
          if (delta.id === downloadId && ['complete', 'interrupted'].includes(delta.state?.current)) {
            URL.revokeObjectURL(url);chrome.downloads.onChanged.removeListener(cleanup);
          }
        };
        chrome.downloads.onChanged.addListener(cleanup);
        setTimeout(() => { URL.revokeObjectURL(url);chrome.downloads.onChanged.removeListener(cleanup); }, 600000);
      } catch (exception) { URL.revokeObjectURL(url);throw exception; }
    };
  }
  if ('showSaveFilePicker' in window) {
    const options = { suggestedName: filename };
    if (mime === 'application/zip') options.types = [{ description: 'Arquivo ZIP', accept: { 'application/zip': ['.zip'] } }];
    const handle = await window.showSaveFilePicker(options);
    return async bytes => {
      const writable = await handle.createWritable();
      try { await writable.write(new Blob([bytes], { type: mime }));await writable.close(); }
      catch (exception) { await writable.abort().catch(() => {});throw exception; }
    };
  }
  throw new Error('Este navegador não disponibilizou o diálogo de salvamento. Abra a extensão no Chrome do computador.');
}

export function isCancelled(exception) {
  return exception.name === 'AbortError' || /cancel(?:led|ed|ado)/i.test(exception.message || '');
}
