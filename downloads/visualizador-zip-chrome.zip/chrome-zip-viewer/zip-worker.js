import { zipSync } from './vendor/fflate.js';
self.onmessage = event => {
  try {
    const contents = Object.create(null);
    for (const entry of event.data) {
      const path = entry.path.replaceAll('\\', '/');
      if (!path || path.startsWith('/') || path.split('/').includes('..') || /^[A-Za-z]:/.test(path) || path.includes('\0')) throw new Error('Nome de arquivo inválido.');
      if (Object.hasOwn(contents, path)) throw new Error('Há dois arquivos com o mesmo caminho: ' + path);
      // Avoid wasting CPU trying to compress already compressed formats.
      const compressed = /\.(zip|gz|7z|rar|png|jpe?g|gif|webp|avif|mp[34]|woff2?)$/i.test(path);
      contents[path] = [new Uint8Array(entry.bytes), { level: compressed ? 0 : 9 }];
    }
    const result = zipSync(contents, { level: 9 });
    self.postMessage({ bytes: result.buffer }, [result.buffer]);
  } catch (exception) { self.postMessage({ error: exception.message }); }
};
