const LIMITS = { archive: 100 * 1024 ** 2, file: 32 * 1024 ** 2, total: 128 * 1024 ** 2, entries: 5000 };
const crcTable = Uint32Array.from({ length: 256 }, (_, value) => {
  for (let bit = 0; bit < 8; bit++) value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
  return value >>> 0;
});
function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) crc = crcTable[(crc ^ byte) & 255] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}
function invalid(message = 'O arquivo ZIP está incompleto ou possui uma estrutura inválida.') { throw new Error(message); }

export async function openZip(file) {
  if (file.size > LIMITS.archive) invalid('O ZIP excede o limite de 100 MB.');
  const buffer = await file.arrayBuffer();
  const view = new DataView(buffer);
  let end = -1;
  for (let offset = buffer.byteLength - 22; offset >= Math.max(0, buffer.byteLength - 65557); offset--) {
    if (view.getUint32(offset, true) === 0x06054b50 && offset + 22 + view.getUint16(offset + 20, true) === buffer.byteLength) { end = offset;break; }
  }
  if (end < 0) invalid('Não foi possível reconhecer um arquivo ZIP válido.');
  if (view.getUint16(end + 4, true) || view.getUint16(end + 6, true)) invalid('ZIP dividido em vários volumes não é suportado.');
  const count = view.getUint16(end + 10, true);
  const directorySize = view.getUint32(end + 12, true);
  const directoryStart = view.getUint32(end + 16, true);
  if (count === 0xffff || directorySize === 0xffffffff || directoryStart === 0xffffffff) invalid('ZIP64 não é suportado por este visualizador.');
  if (count !== view.getUint16(end + 8, true) || directoryStart + directorySize > end) invalid();
  if (count > LIMITS.entries) invalid('O ZIP excede o limite de 5.000 entradas.');
  const entries = [];
  let position = directoryStart;
  let total = 0;
  for (let index = 0; index < count; index++) {
    if (position + 46 > directoryStart + directorySize || view.getUint32(position, true) !== 0x02014b50) invalid();
    const flags = view.getUint16(position + 8, true);
    const method = view.getUint16(position + 10, true);
    const compressedSize = view.getUint32(position + 20, true);
    const size = view.getUint32(position + 24, true);
    const nameLength = view.getUint16(position + 28, true);
    const extraLength = view.getUint16(position + 30, true);
    const commentLength = view.getUint16(position + 32, true);
    const localOffset = view.getUint32(position + 42, true);
    const next = position + 46 + nameLength + extraLength + commentLength;
    if (next > directoryStart + directorySize || view.getUint16(position + 34, true)) invalid();
    if (size === 0xffffffff || compressedSize === 0xffffffff || localOffset === 0xffffffff) invalid('ZIP64 não é suportado por este visualizador.');
    const nameBytes = new Uint8Array(buffer, position + 46, nameLength);
    const path = new TextDecoder(flags & 0x800 ? 'utf-8' : 'windows-1252').decode(nameBytes).replaceAll('\\', '/');
    if (!path || path.includes('\0') || path.startsWith('/') || /^[A-Za-z]:/.test(path) || path.split('/').includes('..')) invalid('O ZIP contém um caminho de arquivo inválido.');
    if (!path.endsWith('/')) {
      if (size > LIMITS.file) invalid('Um arquivo dentro do ZIP excede o limite de 32 MB.');
      total += size;
      if (total > LIMITS.total) invalid('O conteúdo descompactado excede o limite de 128 MB.');
      entries.push({ path, size, compressedSize, flags, method, localOffset, crc: view.getUint32(position + 16, true), id: index });
    }
    position = next;
  }
  const cache = new Map();
  async function extract(entry) {
    if (!entries.includes(entry)) invalid();
    if (cache.has(entry.id)) return cache.get(entry.id);
    if (entry.flags & 1) invalid('Este arquivo está protegido por senha. ZIPs criptografados não são suportados.');
    const local = entry.localOffset;
    if (local + 30 > directoryStart || view.getUint32(local, true) !== 0x04034b50) invalid();
    if (view.getUint16(local + 6, true) & 1 || view.getUint16(local + 8, true) !== entry.method) invalid();
    const dataStart = local + 30 + view.getUint16(local + 26, true) + view.getUint16(local + 28, true);
    const dataEnd = dataStart + entry.compressedSize;
    if (dataStart > directoryStart || dataEnd > directoryStart) invalid();
    const compressed = new Uint8Array(buffer, dataStart, entry.compressedSize);
    let bytes;
    if (entry.method === 0) bytes = compressed.slice();
    else if (entry.method === 8) {
      if (!globalThis.DecompressionStream) invalid('Atualize o Chrome para usar a descompactação de arquivos.');
      const reader = new Blob([compressed]).stream().pipeThrough(new DecompressionStream('deflate-raw')).getReader();
      const chunks = [];
      let length = 0;
      try {
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          length += value.length;
          if (length > entry.size || length > LIMITS.file) { await reader.cancel();invalid('O tamanho descompactado não corresponde ao informado no ZIP.'); }
          chunks.push(value);
        }
      } finally { reader.releaseLock(); }
      bytes = new Uint8Array(length);
      let offset = 0;
      for (const chunk of chunks) { bytes.set(chunk, offset);offset += chunk.length; }
    } else invalid('O método de compressão deste arquivo não é suportado.');
    if (bytes.length !== entry.size || crc32(bytes) !== entry.crc) invalid('Falha na verificação de integridade do arquivo (CRC32).');
    cache.set(entry.id, bytes);
    return bytes;
  }
  return { name: file.name, entries, total, extract };
}
