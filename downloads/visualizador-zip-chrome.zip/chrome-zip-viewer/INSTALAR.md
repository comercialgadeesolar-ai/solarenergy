# Instalar o Visualizador ZIP local no Chrome

1. Baixe `visualizador-zip-chrome.zip` e extraia o ZIP em uma pasta permanente.
2. No Chrome do computador, abra `chrome://extensions`.
3. Ative **Modo do desenvolvedor**.
4. Clique em **Carregar sem compactação** e selecione a pasta `chrome-zip-viewer` que contém `manifest.json`.
5. No ícone de extensões (peça de quebra-cabeça), fixe **ZIP local — visualizar e compactar**.
6. Clique na extensão e depois em **Abrir ZIP**. Selecione o pacote do site ou outro ZIP compatível.

A extensão não foi publicada na Chrome Web Store. A instalação manual precisa ser feita por você no seu Chrome. Não é possível instalar uma extensão diretamente a partir de um ZIP pelo botão de adicionar plugin do WordPress. O Chrome para Android/iPhone não oferece este modo de instalação de extensões; utilize Chrome de computador. A extensão pede a permissão de gerenciar downloads para apresentar **Salvar como…**; não pede acesso a sites e não envia arquivos a servidores.

## O que pode visualizar

- Lista de pastas e arquivos, com busca por nome/caminho.
- HTML em prévia estática isolada, imagens e textos/código.
- Download individual dos arquivos com verificação CRC32.
- Criação de ZIPs a partir de arquivos ou de uma pasta, com DEFLATE nível 9 e preservação da estrutura. Arquivos já comprimidos, como imagens JPEG/PNG, ficam sem nova compressão para evitar trabalho sem benefício.
- Botões **Salvar ZIP como…** e **Salvar arquivo como…**, para escolher pasta e nome no diálogo do Chrome. O sistema pode exigir permissão para pastas protegidas.

## Compactar e salvar

1. Clique em **Selecionar arquivos** ou **Selecionar pasta**.
2. Informe um nome terminado em `.zip`.
3. Clique em **Compactar em ZIP**. A operação ocorre em segundo plano no navegador.
4. Clique em **Salvar ZIP como…** e escolha o destino. Cancelar o diálogo não apaga seus arquivos.

A extensão inclui a biblioteca fflate 0.8.2, com licença MIT em `vendor/fflate-LICENSE`.

A prévia HTML não executa JavaScript nem carrega recursos externos. Para executar o site 3D, baixe `index2.html` pelo visualizador e abra o HTML baixado no Chrome. Para usar o banner e seus links, baixe `index.html` e `index2.html` na mesma pasta.

ZIPs com senha, ZIP64, arquivos divididos e métodos diferentes de DEFLATE/sem compressão não são suportados. Limites de leitura: ZIP até 100 MB, 5.000 entradas, até 32 MB por arquivo e 128 MB descompactados. Necessita Chrome 114 ou posterior com suporte a `DecompressionStream('deflate-raw')`.

Para remover, acesse `chrome://extensions` e clique em **Remover**.
